#include <unistd.h>

int	main(void)
{
	rush(5, 1);
	return (0);
}
